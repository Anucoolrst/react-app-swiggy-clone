import React, { Component } from "react";

class Allrestaurants extends Component {
  render() {
    return (
      <section className="all-restaurants">
        <div className="all-restaurants_container">
          <span>&#8595;</span> ALL RESTAURANTS
        </div>
      </section>
    );
  }
}

export default Allrestaurants;
